---
name: AuraGuard
colors:
  surface: '#131315'
  surface-dim: '#131315'
  surface-bright: '#39393b'
  surface-container-lowest: '#0e0e10'
  surface-container-low: '#1c1b1d'
  surface-container: '#201f22'
  surface-container-high: '#2a2a2c'
  surface-container-highest: '#353437'
  on-surface: '#e5e1e4'
  on-surface-variant: '#e6bdb8'
  inverse-surface: '#e5e1e4'
  inverse-on-surface: '#313032'
  outline: '#ac8884'
  outline-variant: '#5c403c'
  surface-tint: '#ffb4ab'
  primary: '#ffb4ab'
  on-primary: '#690005'
  primary-container: '#dc2626'
  on-primary-container: '#fff6f5'
  inverse-primary: '#bf0715'
  secondary: '#4edea3'
  on-secondary: '#003824'
  secondary-container: '#00a572'
  on-secondary-container: '#00311f'
  tertiary: '#c0c1ff'
  on-tertiary: '#1000a9'
  tertiary-container: '#5d60eb'
  on-tertiary-container: '#faf6ff'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb4ab'
  on-primary-fixed: '#410002'
  on-primary-fixed-variant: '#93000b'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#e1e0ff'
  tertiary-fixed-dim: '#c0c1ff'
  on-tertiary-fixed: '#07006c'
  on-tertiary-fixed-variant: '#2f2ebe'
  background: '#131315'
  on-background: '#e5e1e4'
  surface-variant: '#353437'
typography:
  display-emergency:
    fontFamily: Geist
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  data-mono:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 16px
  margin-mobile: 20px
  margin-desktop: 48px
  container-max: 1200px
---

## Brand & Style
The design system is built on a **Cyber-Minimalist** aesthetic, blending the high-tech utility of cyberpunk with the restraint of premium security software. It is designed for high-stakes personal safety, where every visual element must communicate authority, reliability, and immediate clarity.

The interface utilizes a **Glassmorphic** approach over deep, void-like backgrounds to simulate a sophisticated heads-up display (HUD). The brand personality is "The Invisible Sentinel": silent and unobtrusive during routine monitoring, but aggressive and high-impact during emergency states. Visuals prioritize high-contrast data visualization and tactical precision.

## Colors
The palette is rooted in a "Total Dark" architecture to preserve night vision and ensure discretion in low-light environments.

- **Base Surfaces:** `zinc-950` (#09090b) serves as the primary void, with `zinc-900` (#18181b) for elevated containers.
- **Emergency Crimson:** `crimson-600` (#DC2626) is reserved exclusively for active threats, SOS triggers, and critical alerts. It should utilize a 0 0 15px outer glow in high-alert states.
- **Secure Emerald:** `emerald-500` (#10B981) indicates "All Clear" or "Monitoring Active" status.
- **Data Indigo:** `indigo-500` (#6366F1) is used for secondary telemetry, such as GPS coordinates and signal strength indicators.
- **Accents:** Use low-opacity white (10-15%) for glassmorphic strokes to define boundaries without heavy visual weight.

## Typography
This design system employs a dual-type approach. **Geist** provides a clean, neutral, and highly legible sans-serif for all primary interactions and status messaging. Its high X-height ensures readability during movement or stress.

**JetBrains Mono** is utilized for all technical telemetry, including timestamps, GPS coordinates, and encrypted logs. This distinction creates a clear mental model for the user: Sans-serif for human interaction; Monospace for system-generated data. For mobile headlines, font sizes above 32px should scale down by 20% to maintain HUD composition.

## Layout & Spacing
The layout follows a **Tactical Grid** model. Elements are aligned to a strict 4px baseline to maintain a precise, engineered feel. 

- **Mobile:** Uses a single-column fluid layout with 20px side margins. Key actions (SOS) are anchored to the bottom "Primary Zone" within easy thumb reach.
- **Emergency HUD:** Overlays use a full-screen take-over with centered, high-impact typography.
- **Data Density:** Content cards utilize tight padding (12px-16px) to maximize the information displayed on a single screen without scrolling, critical for situational awareness.

## Elevation & Depth
Depth is achieved through **Glassmorphism and Tonal Layering** rather than traditional shadows. 

1. **Surface Base:** Zinc-950 (Solid).
2. **Glass Level 1:** Zinc-900 at 60% opacity with a 16px backdrop blur and a 1px border (White @ 10% opacity). Used for standard cards.
3. **Glass Level 2:** Zinc-800 at 80% opacity with a 32px backdrop blur for modals and navigation bars.
4. **Active Glow:** Elements in an "active" or "alert" state emit an outer box-shadow glow using their respective accent color (Crimson or Emerald) with 0 spread and high diffusion (20px-40px).

## Shapes
The shape language is **Technical and Precise**. The design system utilizes "Soft" (0.25rem) corners for standard UI components to maintain a modern feel without appearing overly friendly or "bubbly."

Buttons and status indicators may use **chamfered corners** (45-degree cuts) in the emergency HUD to reinforce the military-grade/cyberpunk aesthetic. Circular shapes are reserved strictly for pulse animations and biometric touchpoints.

## Components
- **Emergency SOS Button:** A large, centered circular component. In standby, it features a subtle Emerald pulse. In "Armed" mode, it turns Crimson with a heavy outer glow and high-frequency pulse animation.
- **Glass Cards:** Semi-transparent containers with a `1px` inner stroke. Use these for location logs and contact lists.
- **Telemetry Chips:** Small, monospaced labels used for battery percentage, signal strength, and "Encrypted" status. They should have a dark background and high-contrast text.
- **Status HUD:** A persistent top-bar showing "System Guard: ACTIVE" in Emerald, utilizing a monospace font.
- **Tactical Inputs:** Form fields are represented as "Underlined Only" or "Full Border" with zero background color, using the accent color for the active cursor and border to simulate a terminal interface.
- **Safety Lists:** Interactive list items with "Chevron-Right" indicators; high touch-target area (min 56px height) to ensure usability during high-stress scenarios.